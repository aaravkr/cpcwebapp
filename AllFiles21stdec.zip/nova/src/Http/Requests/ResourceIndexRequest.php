<?php

namespace Laravel\Nova\Http\Requests;

class ResourceIndexRequest extends NovaRequest
{
    use QueriesResources;
}
